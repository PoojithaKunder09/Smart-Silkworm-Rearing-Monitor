package com.reshmenammapride.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.reshmenammapride.models.Batch

@Dao
interface BatchDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(batch: Batch): Long

    @Update
    suspend fun update(batch: Batch)

    @Delete
    suspend fun delete(batch: Batch)

    @Query("SELECT * FROM batches ORDER BY createdAt DESC")
    fun getAllBatches(): LiveData<List<Batch>>

    @Query("SELECT * FROM batches WHERE isActive = 1 ORDER BY createdAt DESC")
    fun getActiveBatches(): LiveData<List<Batch>>

    @Query("SELECT * FROM batches WHERE id = :id")
    suspend fun getBatchById(id: Int): Batch?

    @Query("UPDATE batches SET currentInstar = :instar WHERE id = :id")
    suspend fun updateInstar(id: Int, instar: Int)
}
