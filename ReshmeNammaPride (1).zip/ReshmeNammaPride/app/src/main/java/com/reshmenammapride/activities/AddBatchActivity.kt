package com.reshmenammapride.activities

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.reshmenammapride.database.AppDatabase
import com.reshmenammapride.databinding.ActivityAddBatchBinding
import com.reshmenammapride.models.Batch
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AddBatchActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddBatchBinding
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBatchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        // Set today's date
        val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
        binding.etStartDate.setText(today)

        // Instar spinner
        val instarOptions = listOf("Instar 1", "Instar 2", "Instar 3", "Instar 4", "Instar 5")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, instarOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerInstar.adapter = adapter

        // Breed spinner
        val breeds = listOf("PM x CSR2", "CSR2 x CSR4", "NB4D2 x SH6", "Saggara × Saggara", "Local Variety")
        val breedAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, breeds)
        breedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerBreed.adapter = breedAdapter

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Add New Batch"

        binding.btnSaveBatch.setOnClickListener {
            saveBatch()
        }
    }

    private fun saveBatch() {
        val batchName = binding.etBatchName.text.toString().trim()
        val startDate = binding.etStartDate.text.toString().trim()
        val breedName = binding.spinnerBreed.selectedItem.toString()
        val instarStage = binding.spinnerInstar.selectedItemPosition + 1

        if (batchName.isEmpty()) {
            binding.etBatchName.error = "Please enter a batch name"
            return
        }

        val batch = Batch(
            batchName = batchName,
            breedName = breedName,
            startDate = startDate,
            currentInstar = instarStage
        )

        lifecycleScope.launch {
            database.batchDao().insert(batch)
            runOnUiThread {
                Toast.makeText(this@AddBatchActivity, "Batch '$batchName' created successfully!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
