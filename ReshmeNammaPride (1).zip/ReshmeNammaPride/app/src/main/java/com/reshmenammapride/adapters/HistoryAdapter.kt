package com.reshmenammapride.adapters

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.reshmenammapride.databinding.ItemHistoryBinding
import com.reshmenammapride.models.ClimateRecord
import java.text.SimpleDateFormat
import java.util.*

class HistoryAdapter : ListAdapter<ClimateRecord, HistoryAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemHistoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(record: ClimateRecord) {
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            val date = sdf.format(Date(record.timestamp))

            binding.tvDateTime.text = date
            binding.tvTemp.text = "🌡️ Temp: ${record.temperature}°C"
            binding.tvHumidity.text = "💧 Humidity: ${record.humidity}%"
            binding.tvInstar.text = "🐛 Instar: ${record.instarStage}"
            binding.tvAdviceSummary.text = record.advice.lines().take(2).joinToString("\n")

            val color = when (record.status) {
                "GREEN" -> Color.parseColor("#4CAF50")
                "ORANGE" -> Color.parseColor("#FF9800")
                else -> Color.parseColor("#F44336")
            }
            binding.viewStatusBar.setBackgroundColor(color)
            binding.tvStatus.text = when (record.status) {
                "GREEN" -> "✅ Safe"
                "ORANGE" -> "⚠️ Caution"
                else -> "🔴 Danger"
            }
            binding.tvStatus.setTextColor(color)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<ClimateRecord>() {
        override fun areItemsTheSame(a: ClimateRecord, b: ClimateRecord) = a.id == b.id
        override fun areContentsTheSame(a: ClimateRecord, b: ClimateRecord) = a == b
    }
}
