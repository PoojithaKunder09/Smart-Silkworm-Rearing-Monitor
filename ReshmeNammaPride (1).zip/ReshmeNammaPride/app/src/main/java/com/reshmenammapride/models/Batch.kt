package com.reshmenammapride.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "batches")
data class Batch(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val batchName: String,
    val breedName: String,
    val startDate: String,
    val currentInstar: Int = 1,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
