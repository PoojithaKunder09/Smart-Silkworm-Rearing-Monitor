package com.reshmenammapride.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.reshmenammapride.models.ClimateRecord

@Dao
interface ClimateRecordDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: ClimateRecord): Long

    @Query("SELECT * FROM climate_records WHERE batchId = :batchId ORDER BY timestamp DESC")
    fun getRecordsByBatch(batchId: Int): LiveData<List<ClimateRecord>>

    @Query("SELECT * FROM climate_records ORDER BY timestamp DESC LIMIT 50")
    fun getAllRecords(): LiveData<List<ClimateRecord>>

    @Query("SELECT * FROM climate_records ORDER BY timestamp DESC LIMIT 20")
    suspend fun getRecentRecords(): List<ClimateRecord>

    @Query("DELETE FROM climate_records WHERE batchId = :batchId")
    suspend fun deleteByBatch(batchId: Int)

    @Query("SELECT * FROM climate_records ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestRecord(): ClimateRecord?
}
