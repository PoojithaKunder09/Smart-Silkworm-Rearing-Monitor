package com.reshmenammapride.utils

data class AdviceResult(
    val status: String,        // GREEN, ORANGE, RED
    val advice: String,
    val colorRes: Int,
    val emoji: String
)

data class InstarRange(
    val minTemp: Float,
    val maxTemp: Float,
    val idealHumidity: Float,
    val humidityTolerance: Float = 10f
)

object SmartAdviceEngine {

    private val instarRanges = mapOf(
        1 to InstarRange(28f, 30f, 85f),
        2 to InstarRange(27f, 29f, 80f),
        3 to InstarRange(26f, 28f, 75f),
        4 to InstarRange(25f, 27f, 70f),
        5 to InstarRange(24f, 26f, 65f)
    )

    fun analyze(temp: Float, humidity: Float, instar: Int): AdviceResult {
        val range = instarRanges[instar] ?: instarRanges[1]!!

        val tempStatus = getTempStatus(temp, range)
        val humidityStatus = getHumidityStatus(humidity, range)

        val overallStatus = when {
            tempStatus == "RED" || humidityStatus == "RED" -> "RED"
            tempStatus == "ORANGE" || humidityStatus == "ORANGE" -> "ORANGE"
            else -> "GREEN"
        }

        val advice = buildAdvice(temp, humidity, instar, range, tempStatus, humidityStatus)
        val emoji = when (overallStatus) {
            "GREEN" -> "✅"
            "ORANGE" -> "⚠️"
            else -> "🔴"
        }

        return AdviceResult(overallStatus, advice, 0, emoji)
    }

    private fun getTempStatus(temp: Float, range: InstarRange): String {
        return when {
            temp > range.maxTemp + 3 -> "RED"
            temp < range.minTemp - 3 -> "RED"
            temp > range.maxTemp -> "ORANGE"
            temp < range.minTemp -> "ORANGE"
            else -> "GREEN"
        }
    }

    private fun getHumidityStatus(humidity: Float, range: InstarRange): String {
        val diff = Math.abs(humidity - range.idealHumidity)
        return when {
            diff > 20 -> "RED"
            diff > 10 -> "ORANGE"
            else -> "GREEN"
        }
    }

    private fun buildAdvice(
        temp: Float, humidity: Float, instar: Int,
        range: InstarRange, tempStatus: String, humidityStatus: String
    ): String {
        val sb = StringBuilder()
        sb.append("📊 Instar $instar Analysis:\n")
        sb.append("Ideal Temp: ${range.minTemp}°C - ${range.maxTemp}°C | Ideal Humidity: ${range.idealHumidity}%\n\n")

        when (tempStatus) {
            "RED" -> {
                if (temp > range.maxTemp) {
                    sb.append("🔴 DANGER: Temperature ${temp}°C is critically high!\n")
                    sb.append("→ Immediately open all windows and increase ventilation.\n")
                    sb.append("→ Spread wet gunny bags around the rearing house.\n")
                    sb.append("→ Use fans to circulate air.\n")
                } else {
                    sb.append("🔴 DANGER: Temperature ${temp}°C is critically low!\n")
                    sb.append("→ Close all windows and doors immediately.\n")
                    sb.append("→ Use heaters or increase insulation.\n")
                }
            }
            "ORANGE" -> {
                if (temp > range.maxTemp) {
                    sb.append("⚠️ CAUTION: Temperature ${temp}°C is slightly high.\n")
                    sb.append("→ Open windows partially for ventilation.\n")
                    sb.append("→ Monitor closely every 30 minutes.\n")
                } else {
                    sb.append("⚠️ CAUTION: Temperature ${temp}°C is slightly low.\n")
                    sb.append("→ Partially close windows to retain warmth.\n")
                }
            }
            "GREEN" -> sb.append("✅ Temperature ${temp}°C is ideal for Instar $instar.\n")
        }

        sb.append("\n")

        when (humidityStatus) {
            "RED" -> {
                if (humidity < range.idealHumidity) {
                    sb.append("🔴 DANGER: Humidity ${humidity}% is critically low!\n")
                    sb.append("→ Spray water on the walls and floor immediately.\n")
                    sb.append("→ Place wet cloth/bags near silkworms.\n")
                    sb.append("→ Increase water sprinkling frequency.\n")
                } else {
                    sb.append("🔴 DANGER: Humidity ${humidity}% is critically high!\n")
                    sb.append("→ Open vents to reduce moisture immediately.\n")
                    sb.append("→ Risk of fungal disease is very high!\n")
                }
            }
            "ORANGE" -> {
                if (humidity < range.idealHumidity) {
                    sb.append("⚠️ CAUTION: Humidity ${humidity}% is low.\n")
                    sb.append("→ Spray water lightly on the rearing trays.\n")
                } else {
                    sb.append("⚠️ CAUTION: Humidity ${humidity}% is slightly high.\n")
                    sb.append("→ Improve air circulation to reduce moisture.\n")
                }
            }
            "GREEN" -> sb.append("✅ Humidity ${humidity}% is ideal for Instar $instar.\n")
        }

        if (tempStatus == "GREEN" && humidityStatus == "GREEN") {
            sb.append("\n🌟 Excellent conditions! Silkworms are thriving. Keep monitoring regularly.")
        }

        // Instar 5 cocoon hint
        if (instar == 5) {
            sb.append("\n\n🐛 Instar 5 Tip: Watch for spinning behavior — cocoon transfer to spinning trays may be needed soon!")
        }

        return sb.toString()
    }

    fun getInstarIdealConditions(instar: Int): InstarRange {
        return instarRanges[instar] ?: instarRanges[1]!!
    }
}
