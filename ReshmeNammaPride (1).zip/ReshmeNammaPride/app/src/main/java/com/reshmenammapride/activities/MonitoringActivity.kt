package com.reshmenammapride.activities

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.reshmenammapride.R
import com.reshmenammapride.database.AppDatabase
import com.reshmenammapride.databinding.ActivityMonitoringBinding
import com.reshmenammapride.models.ClimateRecord
import com.reshmenammapride.notifications.NotificationHelper
import com.reshmenammapride.utils.SmartAdviceEngine
import kotlinx.coroutines.launch

class MonitoringActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMonitoringBinding
    private lateinit var database: AppDatabase
    private var selectedBatchId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMonitoringBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)
        supportActionBar?.title = "Climate Monitor"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setupInstarSpinner()
        setupBatchSpinner()
        setupChart()

        binding.btnCheckCondition.setOnClickListener {
            analyzeCondition()
        }

        loadChartData()
    }

    private fun setupInstarSpinner() {
        val instarOptions = listOf("Instar 1", "Instar 2", "Instar 3", "Instar 4", "Instar 5")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, instarOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerInstar.adapter = adapter
    }

    private fun setupBatchSpinner() {
        database.batchDao().getActiveBatches().observe(this) { batches ->
            if (batches.isEmpty()) {
                binding.tvNoBatch.visibility = View.VISIBLE
                binding.btnCheckCondition.isEnabled = false
            } else {
                binding.tvNoBatch.visibility = View.GONE
                binding.btnCheckCondition.isEnabled = true
                val batchNames = batches.map { "${it.batchName} (${it.breedName})" }
                val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, batchNames)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spinnerBatch.adapter = adapter
                selectedBatchId = batches[0].id

                binding.spinnerBatch.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        selectedBatchId = batches[pos].id
                        binding.spinnerInstar.setSelection(batches[pos].currentInstar - 1)
                        loadChartData()
                    }
                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                })
            }
        }
    }

    private fun analyzeCondition() {
        val tempStr = binding.etTemperature.text.toString().trim()
        val humidityStr = binding.etHumidity.text.toString().trim()

        if (tempStr.isEmpty() || humidityStr.isEmpty()) {
            Toast.makeText(this, "Please enter temperature and humidity", Toast.LENGTH_SHORT).show()
            return
        }

        val temp = tempStr.toFloatOrNull()
        val humidity = humidityStr.toFloatOrNull()

        if (temp == null || humidity == null) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            return
        }

        if (temp < 10 || temp > 45) {
            Toast.makeText(this, "Temperature must be between 10°C and 45°C", Toast.LENGTH_SHORT).show()
            return
        }

        if (humidity < 0 || humidity > 100) {
            Toast.makeText(this, "Humidity must be between 0% and 100%", Toast.LENGTH_SHORT).show()
            return
        }

        val instar = binding.spinnerInstar.selectedItemPosition + 1
        val result = SmartAdviceEngine.analyze(temp, humidity, instar)

        // Update UI
        binding.tvAdviceResult.text = result.advice
        binding.tvAdviceResult.visibility = View.VISIBLE
        binding.cardResult.visibility = View.VISIBLE

        val bgColor = when (result.status) {
            "GREEN" -> getColor(R.color.status_green)
            "ORANGE" -> getColor(R.color.status_orange)
            else -> getColor(R.color.status_red)
        }
        binding.cardIndicator.setCardBackgroundColor(bgColor)
        binding.tvStatusLabel.text = when (result.status) {
            "GREEN" -> "✅ SAFE"
            "ORANGE" -> "⚠️ CAUTION"
            else -> "🔴 DANGER"
        }
        binding.tvStatusEmoji.text = result.emoji

        // Save to DB
        if (selectedBatchId != -1) {
            val record = ClimateRecord(
                batchId = selectedBatchId,
                temperature = temp,
                humidity = humidity,
                instarStage = instar,
                advice = result.advice,
                status = result.status
            )
            lifecycleScope.launch {
                database.climateRecordDao().insert(record)
            }

            // Send notification if warning or danger
            if (result.status != "GREEN") {
                val title = if (result.status == "RED") "Silkworm DANGER Alert!" else "Silkworm Caution Alert"
                val msg = "Temp: ${temp}°C | Humidity: ${humidity}% | Instar $instar conditions need attention!"
                NotificationHelper.sendAlert(this, title, msg, result.status)
            }
        }

        loadChartData()
    }

    private fun setupChart() {
        binding.lineChart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            legend.isEnabled = true
            setDrawGridBackground(false)
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.granularity = 1f
            axisRight.isEnabled = false
        }
    }

    private fun loadChartData() {
        lifecycleScope.launch {
            val records = database.climateRecordDao().getRecentRecords()
            if (records.isEmpty()) return@launch

            val tempEntries = records.reversed().mapIndexed { i, r -> Entry(i.toFloat(), r.temperature) }
            val humidityEntries = records.reversed().mapIndexed { i, r -> Entry(i.toFloat(), r.humidity) }
            val labels = records.reversed().map { "#${it.id}" }

            val tempDataSet = LineDataSet(tempEntries, "Temperature (°C)").apply {
                color = Color.RED
                setCircleColor(Color.RED)
                lineWidth = 2f
                circleRadius = 3f
                setDrawValues(false)
            }

            val humidityDataSet = LineDataSet(humidityEntries, "Humidity (%)").apply {
                color = Color.BLUE
                setCircleColor(Color.BLUE)
                lineWidth = 2f
                circleRadius = 3f
                setDrawValues(false)
            }

            runOnUiThread {
                binding.lineChart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
                binding.lineChart.data = LineData(tempDataSet, humidityDataSet)
                binding.lineChart.invalidate()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
