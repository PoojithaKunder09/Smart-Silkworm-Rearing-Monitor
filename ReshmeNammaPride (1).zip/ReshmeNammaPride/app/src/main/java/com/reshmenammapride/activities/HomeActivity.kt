package com.reshmenammapride.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.reshmenammapride.database.AppDatabase
import com.reshmenammapride.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        // Observe active batches count
        database.batchDao().getActiveBatches().observe(this) { batches ->
            val count = batches.size
            binding.tvActiveBatches.text = "$count Active Batch${if (count != 1) "es" else ""}"
            binding.tvNoBatches.visibility = if (count == 0) View.VISIBLE else View.GONE
        }

        binding.btnAddBatch.setOnClickListener {
            startActivity(Intent(this, AddBatchActivity::class.java))
        }

        binding.btnStartMonitoring.setOnClickListener {
            startActivity(Intent(this, MonitoringActivity::class.java))
        }

        binding.btnViewHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }
}
