package com.reshmenammapride.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "climate_records")
data class ClimateRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val batchId: Int,
    val temperature: Float,
    val humidity: Float,
    val instarStage: Int,
    val advice: String,
    val status: String, // GREEN, ORANGE, RED
    val timestamp: Long = System.currentTimeMillis()
)
